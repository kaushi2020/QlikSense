export default function ($element, layout) {
  const ext = this;
  const viz = ext.$scope.viz;
}