let pie = {
  layerfield1: {
    label: "Arc Size Field",
    show: {
      field: "layertype",
      values: ["pie"]
    }
  },
  layerscale2: {
    label: "Color Scale",
    show: {
      field: "layertype",
      values: ["pie"]
    }
  },
  primarycolor: {
    label: "Stroke Color",
    show: {
      field: "layertype",
      values: ["pie"]
    }
  },
  primarywidth: {
    label: "Stroke Width",
    show: {
      field: "layertype",
      values: ["pie"]
    }
  },
  primaryopacity: {
    label: "Opacity",
    show: {
      field: "layertype",
      values: ["pie"]
    }
  },
};

export default pie;
