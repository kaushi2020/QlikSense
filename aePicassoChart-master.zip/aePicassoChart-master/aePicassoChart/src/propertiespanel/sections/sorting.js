let sorting =  {
  uses: "sorting"
};

export default sorting;
