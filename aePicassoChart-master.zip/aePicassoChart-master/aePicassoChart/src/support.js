export default {
  snapshot: true,
  export: true,
  exportData: true,
  viewData: true
}
