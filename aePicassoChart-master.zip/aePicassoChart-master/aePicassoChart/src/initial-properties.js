export default {
  qHyperCubeDef: {
    qDimensions: [],
    qMeasures: [],
    qInitialDataFetch: [{
      qTop: 0,
      qLeft: 0,
      qWidth: 3,
      qHeight: 3333
    }]
  },
  selections: 'CONFIRM',
  createdVersion: VERSION,
  picassoprops: {
    scalesDef: [],
    reflines: [],
    cube: {},
    theme: {},
    componentsDef: {
      axis: [],
      layers: []
    }
  }
}
