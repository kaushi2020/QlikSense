QlikSense-To-PDF Extension converts Qlik Sense sheets to PDF Files  

QlikSense-To-PDF is a QlikSense Extension that allows to create a PDF File from a Qlik Sense Sheet view. 
QlikSense-To-PDF only works for the QlikSense Server. We are still developing this extension and our intention 
is to develop the follow features:

-Image rotation: The option of rotating the image taken, in this way it will be possible to take advantage of the whole A4 PDF Files dimensions.
-Improve UX: Improve the design and events behaviour.


******* Not updated since 2018. Please, feel free to alter any code line. I will try to response asap by email. ************
Contact Details:
Oscar Garcia Bofill / oscar.garcia.bofill@gmail.com
